import numpy as np
import matplotlib.pyplot as plt

frequencles = [1, 2, 4, 8]

SAMPLING_RATE = 100
t = np.arange(0, 1, 1/SAMPLING_RATE)

plt.figure(figsize=(4, 6))

for i, freq in enumerate(frequencles, 1):
    harmonic_signal = np.sin(2 * np.pi * freq * t)
    digital_signal = np.sign(harmonic_signal)

    plt.subplot(4, 2, 2*i - 1)
    plt.plot(t, harmonic_signal)
    plt.plot(t, digital_signal)
    plt.title(f'График сигналов {freq} Гц')
    plt.xlabel('Время (сек.)')
    plt.ylabel('Амплитуда')

    harmonic_freqs = np.fft.fftfreq(len(harmonic_signal), 1/SAMPLING_RATE)
    harmonic_spectr = np.fft.fft(harmonic_signal)

    digital_freqs = np.fft.fftfreq(len(digital_signal), 1 / SAMPLING_RATE)
    digital_spectr = np.fft.fft(digital_signal)

    plt.subplot(4, 2, 2 * i)
    plt.plot(harmonic_freqs, np.abs(harmonic_spectr))
    plt.plot(digital_freqs, np.abs(digital_spectr))
    plt.title(f'Спектр сигналов частотой {freq} Гц')
    plt.xlabel('Частота (Гц)')
    plt.ylabel('Амплитуда')

plt.show()